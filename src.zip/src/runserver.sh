#!/bin/bash
"C:\Users\mathi\OneDrive\Documents\BUT2\PYCHARM PROJECT\pythonProject\venv\Scripts\python.exe" "C:\Users\mathi\OneDrive\Documents\BUT2\PYCHARM PROJECT\pythonProject\src\manage.py" runserver
